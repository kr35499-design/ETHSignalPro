ETH Signal Pro Android Project (V1.0)

मोबाइल से APK बनाने के आसान चरण:
1. GitHub पर अपना अकाउंट बनाएं/लॉगिन करें।
2. New repository बनाएं, नाम ETHSignalPro रखें।
3. इस ZIP को फोन में Extract करें।
4. Extract किए गए सभी फोल्डर/फाइलें repository में upload करें (hidden .github folder सहित)।
5. GitHub repository में Actions टैब खोलें।
6. 'Build ETH Signal Pro APK' workflow चुनकर Run workflow दबाएं।
7. Build पूरा होने पर workflow run खोलें। नीचे Artifacts में ETH-Signal-Pro-debug-APK डाउनलोड करें।
8. ZIP खोलकर app-debug.apk निकालें और Android में install करें। जरूरत हो तो browser/files app को 'Install unknown apps' अनुमति दें।

ध्यान:
- यह debug APK है, Play Store release/signing के लिए नहीं।
- APK में वही V1.0 HTML है।
- ऐप सिर्फ सार्वजनिक ETH candle API से डेटा पढ़ता है; कोई API key या auto-trading नहीं।
- API/network/CORS या exchange endpoint बदलने पर लाइव डेटा फेल हो सकता है। पहले paper test करें।
